<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="procesar.php" method="get">
        <p>Nombre</p> <input type="text" name="nombre" id="">
        <p>Apellido</p> <input type="text" name="apellido" id="">
        <p>Descripcion</p> <input type="text" name="descripcion" id="">
        <p><input type="submit" value="Enviar"></p>
    </form>
</body>
</html>